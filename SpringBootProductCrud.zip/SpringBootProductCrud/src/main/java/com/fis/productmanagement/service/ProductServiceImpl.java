package com.fis.productmanagement.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.productmanagement.model.Product;
import com.fis.productmanagement.repository.ProductRepo;

@Service
@Transactional
public class ProductServiceImpl implements ProductService {
	@Autowired
	ProductRepo repo;

	@Override
	public String addProduct(Product product) {

		return repo.addProduct(product);
	}

	@Override
	public String updateProduct(Product product) {
		return repo.updateProduct(product);
	}

	@Override
	public String deleteProduct(int productId) {
		return repo.deleteProduct(productId);
	}

	@Override
	public Product getProduct(int productId) {
		return repo.getProduct(productId);
	}

	@Override
	public List<Product> getAllProducts() {
		return repo.getAllProducts();
	}

	@Override
	public List<Product> getAllProductsBetween(int intialPrice, int finalPrice) {
		return repo.getAllProductsBetween(intialPrice, finalPrice);
	}

	@Override
	public List<Product> getAllProductsByCategory(String category) {
		return repo.getAllProductsByCategory(category);
	}

}
