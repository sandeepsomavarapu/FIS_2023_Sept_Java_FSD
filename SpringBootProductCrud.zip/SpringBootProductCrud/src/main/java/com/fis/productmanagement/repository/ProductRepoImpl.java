package com.fis.productmanagement.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.fis.productmanagement.model.Product;

@Repository
public class ProductRepoImpl implements ProductRepo {
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public String addProduct(Product product) {
		entityManager.persist(product);
		return "Product Saved Successfully";
	}

	@Override
	public String updateProduct(Product product) {
		entityManager.merge(product);
		return "Product Updated Successfully";
	}

	@Override
	public String deleteProduct(int productId) {
		entityManager.remove(getProduct(productId));
		return "Product Removed Successfully";
	}

	@Override
	public Product getProduct(int productId) {

		return entityManager.find(Product.class, productId);
	}

	@Override
	public List<Product> getAllProducts() {
		TypedQuery<Product> query = entityManager.createQuery("select p from Product p", Product.class);
		return query.getResultList();
	}

	@Override
	public List<Product> getAllProductsBetween(int intialPrice, int finalPrice) {
		TypedQuery<Product> query = entityManager
				.createQuery("select p from Product p where p.productPrice between ?1 and ?2", Product.class);
		query.setParameter(1, intialPrice);
		query.setParameter(2, finalPrice);
		return query.getResultList();
	}

	@Override
	public List<Product> getAllProductsByCategory(String category) {
		TypedQuery<Product> query = entityManager.createQuery("select p from Product p where p.productCategory=?1",
				Product.class);
		query.setParameter(1, category);
		return query.getResultList();
	}

}
