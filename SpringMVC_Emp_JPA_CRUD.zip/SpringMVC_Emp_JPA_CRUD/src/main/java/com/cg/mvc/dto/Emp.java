package com.cg.mvc.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.lang.NonNull;

@Entity
@Table(name="emp_master")
public class Emp {  
	
@Id
@GeneratedValue
@Column(name="emp_Id")
private int id; 

@Column(name="emp_name")
@NotEmpty(message="Name cannot be empty")
@Size(min=3,max=10,message="Name should be between 3 and 10 letters")
private String name; 

@Column(name="salary")
@NotNull(message="Salary cannot be empty")
private float salary;


@NotNull(message="Designation cannot be empty")
private String designation;  
  
public int getId() {  
    return id;  
}  
public void setId(int id) {  
    this.id = id;  
}  
public String getName() {  
    return name;  
}  
public void setName(String name) {  
    this.name = name;  
}  
public float getSalary() {  
    return salary;  
}  
public void setSalary(float salary) {  
    this.salary = salary;  
}  
public String getDesignation() {  
    return designation;  
}  
public void setDesignation(String designation) {  
    this.designation = designation;  
}  
  
}  