package com.example.SpringbootDemoWithH2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootDemoWithH2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootDemoWithH2Application.class, args);
	}

}
