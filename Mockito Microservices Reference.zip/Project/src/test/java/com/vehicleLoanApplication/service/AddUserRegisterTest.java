package com.vehicleLoanApplication.service;

 

import static org.junit.jupiter.api.Assertions.assertEquals;

 


 

 

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

 


 

 

import com.vehicleloanapplication.dao.UserRegisterJPARepository;
import com.vehicleloanapplication.exceptions.DuplicateRecordException;
import com.vehicleloanapplication.exceptions.RecordNotFoundException;
import com.vehicleloanapplication.model.UserRegistrationEntity;
import com.vehicleloanapplication.service.UserRegisterServiceImpl;

 


 

 


@SpringBootTest
public class AddUserRegisterTest {

 

 

 

    @Autowired
    private UserRegisterServiceImpl userRegisterService;
    
    @MockBean
    UserRegisterJPARepository userRegisterRepo;
    
    //NO EMAIL ENTERED 
    @Test
    @DisplayName("userRegister - no email")
    public void emailNotEntered() throws DuplicateRecordException {
        String email=null;
        UserRegistrationEntity userRegisterEntity=new UserRegistrationEntity("",41,"female","9988776611","wonderlands","SaiRam",null);
        //userRegisterEntity.setEmail(email);
        Mockito.when(userRegisterRepo.saveAndFlush(userRegisterEntity)).thenReturn(userRegisterEntity);
        UserRegistrationEntity updatelist=null;
        try {
            updatelist=userRegisterService.userRegister(userRegisterEntity);
       } catch (DuplicateRecordException e) {
           // TODO Auto-generated catch block
           assertEquals(e.getMessage(),"User details should not be null");
           //e.printStackTrace();
       }
        
    }
    //USER REGISTER SUCCESSFUL
    @Test
    @DisplayName("userRegister - successful")
    public void addcorrectdetails() throws RecordNotFoundException, DuplicateRecordException {
        UserRegistrationEntity userRegisterEntity=new UserRegistrationEntity("wonders@gmail.com",41,"female","9988776611","wonderlands","SaiRam",null);
        Mockito.when(userRegisterRepo.saveAndFlush(userRegisterEntity)).thenReturn(userRegisterEntity);
        UserRegistrationEntity updatelist=null;
        updatelist=userRegisterService.userRegister(userRegisterEntity);
        assertEquals(updatelist,userRegisterEntity);
    }
    //ADDED WRONG DETAILS
    @Test
    @DisplayName("userRegister - added wrong details")
    public void addincorrectdetails() throws RecordNotFoundException, DuplicateRecordException {
        String email="wonders";
        UserRegistrationEntity userRegisterEntity1=new UserRegistrationEntity("wonders",41,"female","9988776611","wonderlands","SaiRam",null);
        UserRegistrationEntity userRegisterEntity2=null;
        Mockito.when(userRegisterRepo.saveAndFlush(userRegisterEntity1)).thenReturn(userRegisterEntity1);
        userRegisterEntity2=userRegisterService.userRegister(userRegisterEntity1);
        assertEquals(email,userRegisterEntity2.getEmail());
    }
    //ADDED ALREADY EXISTING DETAILS
    @Test
    @DisplayName("userRegister - added already existing details")
    public void addAlreadyExisingUser() throws RecordNotFoundException {
        String email="wonders@gmail.com";
        UserRegistrationEntity userRegisterEntity1=new UserRegistrationEntity("wonders@gmail.com",41,"female","9988776611","wonderlands","SaiRam",null);
        UserRegistrationEntity userRegisterEntity2=new UserRegistrationEntity("wonders@gmail.com",41,"female","9988776611","wonderlands","SaiRam",null);
        Mockito.when(userRegisterRepo.saveAndFlush(userRegisterEntity1)).thenReturn(userRegisterEntity1);
        try {
            assertEquals(userRegisterService.userRegister(userRegisterEntity1).getEmail(),email);
        } catch (DuplicateRecordException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

 

 

 

}