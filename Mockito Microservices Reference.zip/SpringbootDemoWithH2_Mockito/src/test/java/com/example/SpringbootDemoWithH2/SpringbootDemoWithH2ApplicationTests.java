package com.example.SpringbootDemoWithH2;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.example.SpringbootDemoWithH2.model.Student;
import com.example.SpringbootDemoWithH2.repository.StudentRepository;
import com.example.SpringbootDemoWithH2.service.StudentService;

@SpringBootTest
public class SpringbootDemoWithH2ApplicationTests {
	@Autowired
	private StudentService studentService;
	@MockBean
	private static StudentRepository studentRepository;

	@Test
	public void getUserByName() {

		String name = "naresh";
		Student student = new Student();
		student.setStudentName("naresh");
		student.setStudentId(1);
		student.setStudentMarks(200);
		student.setStudentGrade("A");
		Mockito.when(studentRepository.findByStudentName(student.getStudentName())).thenReturn(student);
		Student student1 = studentService.getStudentByName(name);
		Assert.assertEquals(student1.getStudentName(), name);
	}

	@Test
	public void saveStudent() {

		Student student = new Student(123, "sandeep", 300, "A");
		studentService.addStudent(student);

		verify(studentRepository, times(1)).save(student);
	}

	@Test
	public void getAllUsers() {

		Student student = new Student();
		student.setStudentName("naresh");
		student.setStudentId(1);
		student.setStudentMarks(200);
		student.setStudentGrade("A");

		Student student1 = new Student();
		student1.setStudentName("mahesh");
		student1.setStudentId(2);
		student1.setStudentMarks(800);
		student1.setStudentGrade("B");
	
		List<Student> students = new ArrayList<Student>();
		students.add(student);
		students.add(student1);

		Mockito.when(studentRepository.findAll()).thenReturn(students);

		List<Student> students1 = studentService.getAllStudents();
		Assert.assertEquals(students1.size(), 2);
	}
}