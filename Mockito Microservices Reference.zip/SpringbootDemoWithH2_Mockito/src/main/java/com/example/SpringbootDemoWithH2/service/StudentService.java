package com.example.SpringbootDemoWithH2.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.SpringbootDemoWithH2.model.Student;
import com.example.SpringbootDemoWithH2.repository.StudentRepository;

@Service
public class StudentService {
	@Autowired
	StudentRepository repo;

	public String addStudent(Student student) {
		repo.save(student);
		return "Student Saved Successfully";

	}
	public String updateStudent(Student student) {
		repo.save(student);
		return "Student Updated Successfully";

	}

	public Student getStudent(int studentId) {
		Optional<Student> optional = repo.findById(studentId);
		return optional.get();

	}
	public Student getStudentByName(String studentName) {
		Student student = repo.findByStudentName(studentName);
		return student;

	}

	public List<Student> getAllStudents() {
		List<Student> students = new ArrayList<Student>();
		repo.findAll().forEach(s -> students.add(s));
		return students;
	}

	public String deleteStudent(int studentId) {
		repo.deleteById(studentId);
		return "Student Deleted Successfully";

	}

}
