package com.example.SpringbootDemoWithH2.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.SpringbootDemoWithH2.model.Student;
import com.example.SpringbootDemoWithH2.service.StudentService;

//{
//"studentId":111,
//"studentName":"mahesh",
//"studentMarks":900,
//"studentGrade":"A"
//}
@RestController
public class StudentController {

	@Autowired
	StudentService service;

	@PostMapping("/saveStudent")  //http://localhost:8080/saveStudent
	public String addStudent(@RequestBody Student student) {
		return service.addStudent(student);
	}
	@PutMapping("/updateStudent")  //http://localhost:8080/updateStudent
	public String updateStudent(@RequestBody Student student) {
		return service.updateStudent(student);
	}

	@GetMapping("/findStudent/{sid}")//http://localhost:8080/findStudent/111
	public Student getStudent(@PathVariable("sid") int studentId) {
		return service.getStudent(studentId);
	}

	@GetMapping("/findAll")//http://localhost:8080/findAll
	public List<Student> getAllStudents() {
		return service.getAllStudents();
	}

	@DeleteMapping("/deleteStudent/{sid}")//http://localhost:8080/deleteStudent/111
	public String deleteStudent(@PathVariable("sid") int studentId) {
		return service.deleteStudent(studentId);
	}

}
