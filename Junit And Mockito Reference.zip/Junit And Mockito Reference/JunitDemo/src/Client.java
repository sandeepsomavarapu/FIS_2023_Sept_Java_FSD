import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class Client {

	TestCalc test = new TestCalc();

	int actual = test.addition(12, 13);

	int expected =25;
	@Test
	public void testAdd() {
		assertEquals(expected, actual);
	}

}