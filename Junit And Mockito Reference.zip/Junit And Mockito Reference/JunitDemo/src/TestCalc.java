public class TestCalc {

	public int addition(int a, int b) {
		return a + b;
	}
}
