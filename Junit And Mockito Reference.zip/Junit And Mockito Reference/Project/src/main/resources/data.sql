Insert into user_details (user_aadhar_url, user_address, user_address_proof,user_city, user_emptype,user_pan_url,user_pin, user_salary,user_salary_slip, user_state)
Values("ayz.url","Ruby Elite","abcd.url","Chennai","Regular","sdfd.url","600073",500000.0,"VJHHGFJ5467A.url","Tamil Nadu");

Insert into loan_application (chassis_no,loan_amount,loan_application_date,vehicle_brand,vehicle_colour, vehicle_ex_showroom_price, existing_emi,loan_interest,vehicle_model, vehicle_on_road_price,loan_application_status,loan_tenure,vehicle_type,user_id)
values("12hg45",100000.0,'2020-10-19',"mercedes","red",6000000.0,100000.0,10.0,"cls",7000000.0,"pending",5,4,1);