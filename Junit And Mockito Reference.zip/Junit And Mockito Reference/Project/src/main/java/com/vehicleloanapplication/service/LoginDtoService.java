package com.vehicleloanapplication.service;

import java.util.List;

import org.springframework.stereotype.Service;


import com.vehicleloanapplication.exceptions.RecordNotFoundException;
import com.vehicleloanapplication.exceptions.RegistrationException;
import com.vehicleloanapplication.model.AdminEntity;
import com.vehicleloanapplication.model.UserRegistrationEntity;


@Service
public interface LoginDtoService {
	public UserRegistrationEntity authenticateUser(String userEmail,String password) throws RegistrationException, RecordNotFoundException ;
   public List<UserRegistrationEntity> getAllUsersDetails();
   public AdminEntity authenticateAdmin(String adminEmail,String password) throws RegistrationException, RecordNotFoundException;
   public List<AdminEntity> getAllAdminDetails();
   

}