package com.fis.productmanagement;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.fis.productmanagement.model.Product;
import com.fis.productmanagement.repository.ProductRepo;
import com.fis.productmanagement.service.ProductService;

@SpringBootTest
class SpringBootProductCrudApplicationTests {

	@MockBean
	ProductRepo repo;
	@Autowired
	ProductService service;

	@Test
	public void testAddProduct() {
		Product product = new Product(323, "samsung", 23000, "electronics");
		Mockito.doReturn("Product Saved Successfully").when(repo).addProduct(product);
		String msg = service.addProduct(product);
		assertEquals("Product Saved Successfully", msg);
	}

}// @Mock @InjectMocks
