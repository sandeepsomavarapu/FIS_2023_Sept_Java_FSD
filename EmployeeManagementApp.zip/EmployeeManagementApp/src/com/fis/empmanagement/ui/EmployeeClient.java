package com.fis.empmanagement.ui;

import java.util.Scanner;

import com.fis.empmanagement.beans.Employee;
import com.fis.empmanagement.service.EmployeeService;
import com.fis.empmanagement.service.EmployeeServiceImpl;

public class EmployeeClient {
	public static void main(String[] args) {
		int empNo = 1000;
		String empName;
		float empSal;
		String empDesg;
		String empAdd;
		EmployeeService service = new EmployeeServiceImpl();
		Scanner scanner = new Scanner(System.in);
		while (true) {
			System.out.println("********Employee Management Application********");
			System.out.println("1.Add Employee");
			System.out.println("2.Update Employee");
			System.out.println("3.Delete Employee");
			System.out.println("4.Get Employee By Empno");
			System.out.println("5.Get All Employees");
			System.out.println("6.Get All Employees Between Salries");
			System.out.println("7.Get All Employees By Designation");
			System.out.println("8.Exit");
			int option = scanner.nextInt();

			switch (option) {
			case 1:
				System.out.println("Enter Employee Details To Add");
				System.out.println("Enter Your Name");
				empName = scanner.next();
				System.out.println("Enter Your Salary");
				empSal = scanner.nextFloat();
				System.out.println("Enter Your Designation");
				empDesg = scanner.next();
				System.out.println("Enter Your Address");
				empAdd = scanner.next();
				++empNo;
				Employee employee = new Employee(empNo, empName, empSal, empDesg, empAdd);
				System.out.println(service.addEmployee(employee));
				break;
			case 2:

				break;
			case 3:

				break;
			case 4:

				break;
			case 5:

				break;
			case 6:

				break;
			case 7:

				break;
			default:
				System.out.println("Thank You !!!!");
				scanner.close();
				System.exit(0);
				break;
			}
		}

	}

}
