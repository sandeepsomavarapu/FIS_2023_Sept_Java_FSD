package com.fis.empmanagement.service;

import java.util.Set;

import com.fis.empmanagement.beans.Employee;
import com.fis.empmanagement.exceptions.EmployeeNotFound;
import com.fis.empmanagement.repo.EmployeeRepo;
import com.fis.empmanagement.repo.EmployeeRepoImpl;

public class EmployeeServiceImpl implements EmployeeService {

	EmployeeRepo dao = new EmployeeRepoImpl();

	@Override
	public String addEmployee(Employee employee) {
		return dao.addEmployee(employee);
	}

	@Override
	public String updateEmployee(Employee employee) throws EmployeeNotFound {

		return dao.updateEmployee(employee);
	}

	@Override
	public String deleteEmployee(int empId) throws EmployeeNotFound {

		return dao.deleteEmployee(empId);
	}

	@Override
	public Employee getEmployee(int empId) throws EmployeeNotFound {

		return dao.getEmployee(empId);
	}

	@Override
	public Set<Employee> getAllEmployees() {

		return dao.getAllEmployees();
	}

	@Override
	public Set<Employee> getAllEmployeesInBetween(float intialSal, float finalSal) {

		return dao.getAllEmployeesInBetween(intialSal, finalSal);
	}

	@Override
	public Set<Employee> getAllEmployeesByDesignation(String designation) {

		return dao.getAllEmployeesByDesignation(designation);
	}

}
