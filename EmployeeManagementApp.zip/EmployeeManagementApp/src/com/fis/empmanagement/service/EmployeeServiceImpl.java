package com.fis.empmanagement.service;

import com.fis.empmanagement.beans.Employee;
import com.fis.empmanagement.repo.EmployeeRepo;
import com.fis.empmanagement.repo.EmployeeRepoImpl;

public class EmployeeServiceImpl implements EmployeeService {

	EmployeeRepo dao = new EmployeeRepoImpl();

	@Override
	public String addEmployee(Employee employee) {
		return dao.addEmployee(employee);
	}

}
