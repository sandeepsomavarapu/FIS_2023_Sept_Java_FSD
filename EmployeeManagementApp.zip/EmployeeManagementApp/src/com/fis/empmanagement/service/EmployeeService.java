package com.fis.empmanagement.service;

import java.util.Set;

import com.fis.empmanagement.beans.Employee;
import com.fis.empmanagement.exceptions.EmployeeNotFound;

public interface EmployeeService {

	public abstract String addEmployee(Employee employee);

	public abstract String updateEmployee(Employee employee) throws EmployeeNotFound;

	public abstract String deleteEmployee(int empId) throws EmployeeNotFound;

	public abstract Employee getEmployee(int empId) throws EmployeeNotFound;

	public abstract Set<Employee> getAllEmployees();

	public abstract Set<Employee> getAllEmployeesInBetween(float intialSal, float finalSal);

	public abstract Set<Employee> getAllEmployeesByDesignation(String designation);
}
