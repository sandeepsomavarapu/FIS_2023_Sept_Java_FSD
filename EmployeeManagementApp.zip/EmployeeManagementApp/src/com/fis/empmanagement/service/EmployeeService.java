package com.fis.empmanagement.service;

import com.fis.empmanagement.beans.Employee;

public interface EmployeeService {

	public abstract String addEmployee(Employee employee);
}
