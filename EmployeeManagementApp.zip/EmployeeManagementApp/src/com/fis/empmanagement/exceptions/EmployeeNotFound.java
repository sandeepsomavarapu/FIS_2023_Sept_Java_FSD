package com.fis.empmanagement.exceptions;

public class EmployeeNotFound extends Exception {//Throwable,Exception,RuntimeException

	public EmployeeNotFound(String message) {
		super(message);
	}

}
