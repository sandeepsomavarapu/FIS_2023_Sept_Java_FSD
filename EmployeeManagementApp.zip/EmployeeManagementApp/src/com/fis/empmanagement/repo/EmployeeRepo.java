package com.fis.empmanagement.repo;

import com.fis.empmanagement.beans.Employee;

public interface EmployeeRepo {
	public abstract String addEmployee(Employee employee);
}
