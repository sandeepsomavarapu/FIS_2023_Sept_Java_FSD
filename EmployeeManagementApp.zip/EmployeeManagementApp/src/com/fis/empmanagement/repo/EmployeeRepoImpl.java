package com.fis.empmanagement.repo;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import com.fis.empmanagement.beans.Employee;
import com.fis.empmanagement.exceptions.EmployeeNotFound;

public class EmployeeRepoImpl implements EmployeeRepo {

	HashMap<Integer, Employee> employees = new HashMap<Integer, Employee>();

	@Override
	public String addEmployee(Employee employee) {
		employees.put(employee.getEmpNo(), employee);
		return "Employee Saved Successfully";
	}

	@Override
	public String updateEmployee(Employee employee) throws EmployeeNotFound {// 123
		if (employees.containsKey(employee.getEmpNo())) {
			employees.put(employee.getEmpNo(), employee);
			return "Employee Updated Successfully";
		} else {
			throw new EmployeeNotFound("Invalid Employee Id");
		}
	}

	@Override
	public String deleteEmployee(int empId) throws EmployeeNotFound {
		if (employees.containsKey(empId)) {
			employees.remove(empId);
			return "Employee Deleted Successfully";
		} else {
			throw new EmployeeNotFound("Invalid Employee Id");
		}
	}

	@Override
	public Employee getEmployee(int empId) throws EmployeeNotFound {
		if (employees.containsKey(empId)) {
			return employees.get(empId);
		} else {
			throw new EmployeeNotFound("Invalid Employee Id");
		}

	}

	@Override
	public Set<Employee> getAllEmployees() {
		Set<Integer> set = employees.keySet();
		Set<Employee> emps = new HashSet<Employee>();
		Iterator<Integer> keys = set.iterator();
		while (keys.hasNext()) {
			int key = keys.next();
			emps.add(employees.get(key));
		}
		return emps;
	}

	@Override
	public Set<Employee> getAllEmployeesInBetween(float intialSal, float finalSal) {// 20000 30000
		Set<Integer> set = employees.keySet();
		Set<Employee> emps = new HashSet<Employee>();
		Iterator<Integer> keys = set.iterator();
		while (keys.hasNext()) {
			int key = keys.next();
			Employee emp = employees.get(key);
			float sal = emp.getEmpSal();
			if (sal >= intialSal && sal <= finalSal)
				emps.add(emp);
		}
		return emps;
	}

	@Override
	public Set<Employee> getAllEmployeesByDesignation(String designation) {
		Set<Integer> set = employees.keySet();
		Set<Employee> emps = new HashSet<Employee>();
		Iterator<Integer> keys = set.iterator();
		while (keys.hasNext()) {
			int key = keys.next();
			Employee emp = employees.get(key);
			String empDesg = emp.getEmpDesg();
			if (empDesg.equalsIgnoreCase(designation))
				emps.add(emp);
		}
		return emps;
	}

}
