package com.fis.empmanagement.repo;

import java.util.HashMap;

import com.fis.empmanagement.beans.Employee;

public class EmployeeRepoImpl implements EmployeeRepo{

	HashMap<Integer,Employee> employees=new HashMap<Integer,Employee>();
	@Override
	public String addEmployee(Employee employee) {
		employees.put(employee.getEmpNo(), employee);
		return "Employee Saved Successfully";
	}

}
