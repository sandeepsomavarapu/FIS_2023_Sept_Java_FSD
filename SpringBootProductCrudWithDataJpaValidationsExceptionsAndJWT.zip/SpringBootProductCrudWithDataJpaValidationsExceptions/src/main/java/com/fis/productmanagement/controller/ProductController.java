package com.fis.productmanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.fis.productmanagement.exceptions.ProductNotFound;
import com.fis.productmanagement.model.Product;
import com.fis.productmanagement.service.ProductService;

//{
//"productId":111,
//"productName":"samsung",
//"productPrice":93000,
//"productCategory":"electronics"
//}
@RestController
@RequestMapping("/products")
public class ProductController {
	@Autowired
	ProductService service;

	@PostMapping("/addProduct") // http://localhost:8080/products/addProduct
	public String saveProduct(@RequestBody @Validated Product product) {
		return service.addProduct(product);
	}

	@PutMapping("/updateProduct") // http://localhost:8080/products/updateProduct
	public String updateProduct(@RequestBody @Validated Product product) {
		return service.updateProduct(product);
	}

	@DeleteMapping("/deleteProduct/{pid}") // http://localhost:8080/products/deleteProduct/888
	public String deleteProduct(@PathVariable("pid") int productId) {
		try {
			return service.deleteProduct(productId);
		} catch (ProductNotFound e) {
			return "invalid product id...";
		}
	}

	@GetMapping("/getProduct/{pid}") // http://localhost:8080/products/getProduct/888
	public Product getProduct(@PathVariable("pid") int productId) throws ProductNotFound {
		return service.getProduct(productId);

	}

	@GetMapping("/getAllProducts") // http://localhost:8080/products/getAllProducts
	public List<Product> getProducts() {
		return service.getAllProducts();
	}

	@GetMapping("/getAllProductsBetween/{price1}/{price2}") // http://localhost:8080/products/getAllProductsBetween/2000/3000
	public List<Product> getProducts(@PathVariable("price1") int intialPrice, @PathVariable("price2") int finalPrice) {
		return service.getAllProductsBetween(intialPrice, finalPrice);
	}

	@GetMapping("/getAllProductsByCategory/{cate}") // http://localhost:8080/products/getAllProductsByCategory/electronics
	public List<Product> getProductsByCategory(@PathVariable("cate") String category) {
		return service.getAllProductsByCategory(category);
	}

//	@ResponseStatus(value = HttpStatus.NOT_FOUND, reason = "Product with this id not present")
//	@ExceptionHandler({ Exception.class })
//	public void handleException() {
//	}

}
