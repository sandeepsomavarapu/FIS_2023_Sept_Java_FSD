package com.fis.productmanagement.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.fis.productmanagement.model.Product;

public interface ProductRepo extends JpaRepository<Product,Integer> {
//	@Query("select p from Product p where p.productPrice between ?1 and ?2")
//	public List<Product> getAllProductsBetween(int intialPrice,int finalPrice);
//	@Query("select p from Product p where p.productCategory=?1")
//	public List<Product> getAllProductsByCategory(String productCategory);
	
	
	
	//DSL grammer 
	
	public List<Product> findByProductPriceBetween(int intialPrice,int finalPrice);
	
	public List<Product> findByProductCategory(String category);
	
	
}
