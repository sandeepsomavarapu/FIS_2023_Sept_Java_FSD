package com.fis.productmanagement.exceptions;

public class ProductNotFound extends Exception {
	public ProductNotFound(String message) {
		super(message);
	}
}
