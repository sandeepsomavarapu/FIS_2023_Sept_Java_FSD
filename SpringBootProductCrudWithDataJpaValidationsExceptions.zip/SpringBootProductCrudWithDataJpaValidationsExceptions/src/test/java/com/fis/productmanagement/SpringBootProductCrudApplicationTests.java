package com.fis.productmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootProductCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
