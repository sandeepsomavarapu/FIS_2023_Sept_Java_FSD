package com.fis.productmanagement.model;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Past;
import javax.validation.constraints.Size;

@Entity
@Table(name = "products_info")
public class Product {
	@Id
	@Column(name = "pid")
	@Min(value = 100, message = "Product Id Cannot be less than 100")
	@Max(value = 1000, message = "Product Id cannot be greater than 1000") // MANVE
	private int productId;
	@Size(min = 6, max = 15, message = "product name length must be between 6-15")
	@NotBlank(message = "product name cannot be null or whitespace")
	private String productName;
	@Min(value = 100, message = "Product Price Cannot be less than 100")
	private int productPrice;
	@NotBlank(message = "Category cannot be null or whitespace")
	private String productCategory;

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}

	public String getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}

	public Product(int productId, String productName, int productPrice, String productCategory) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productPrice = productPrice;
		this.productCategory = productCategory;
	}

	public Product() {
		// TODO Auto-generated constructor stub
	}
}
