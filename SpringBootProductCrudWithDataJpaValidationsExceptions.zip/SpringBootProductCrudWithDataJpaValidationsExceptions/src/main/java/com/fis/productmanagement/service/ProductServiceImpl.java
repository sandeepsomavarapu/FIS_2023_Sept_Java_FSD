package com.fis.productmanagement.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.productmanagement.exceptions.ProductNotFound;
import com.fis.productmanagement.model.Product;
import com.fis.productmanagement.repository.ProductRepo;

@Service
@Transactional
public class ProductServiceImpl implements ProductService {
	@Autowired
	ProductRepo repo;

	@Override
	public String addProduct(Product product) {
		repo.save(product);
		return "Product Saved Successfully";
	}

	@Override
	public String updateProduct(Product product) {
		repo.save(product);
		return "Product Updated Successfully";
	}

	@Override
	public String deleteProduct(int productId) throws ProductNotFound {
		repo.deleteById(productId);
		return "Product Deleted Successfully";
	}

	@Override
	public Product getProduct(int productId) throws ProductNotFound {
		Optional<Product> optional = repo.findById(productId);
		if (optional.isPresent()) {
			return optional.get();
		} else {
			throw new ProductNotFound("Product Id is invalid...");
		}
	}

	@Override
	public List<Product> getAllProducts() {
		return repo.findAll();
	}

	@Override
	public List<Product> getAllProductsBetween(int intialPrice, int finalPrice) {
		return repo.findByProductPriceBetween(intialPrice, finalPrice);
	}

	@Override
	public List<Product> getAllProductsByCategory(String category) {
		return repo.findByProductCategory(category);
	}

}
