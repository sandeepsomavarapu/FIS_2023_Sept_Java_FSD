package com.fis.productmanagement;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class ProductClient {
	public static void main(String[] args) {

		EntityManagerFactory factory = Persistence.createEntityManagerFactory("mysql");

		EntityManager entityManager = factory.createEntityManager();// insert-->persist(),update-->merge(),delete--remove(),select--find()

		//Product product = new Product(124, "dell", 120000, "laptop");// ORM

		entityManager.getTransaction().begin();
		//entityManager.persist(product);
		
		Product productInfo= entityManager.find(Product.class,123);
		
		
		System.out.println(productInfo);
		
		entityManager.remove(productInfo);
//		
//					productInfo.setProductName("apple");
//					productInfo.setProductPrice(88888);
//					productInfo.setProductDesc("fruits");
//					
//					entityManager.merge(productInfo);
//		
		
		entityManager.getTransaction().commit();
	}
}
