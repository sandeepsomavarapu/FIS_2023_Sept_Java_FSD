package com.fis.springcoredemo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.fis.springcoredemo")
public class TestEmp {
	public static void main(String[] args) {

		ApplicationContext factory = new AnnotationConfigApplicationContext(TestEmp.class);

		Employee emp1 = (Employee) factory.getBean("emp1");
		System.out.println(emp1);
		System.out.println(emp1.getAddress());

	}

	@Bean("emp1")
	public Employee getEmployee() {
		Employee emp = new Employee();
		emp.setAddress(getAddress());
		return emp;
	}

	@Bean
	public Address getAddress() {
		Address add = new Address();
		return add;
	}

}
